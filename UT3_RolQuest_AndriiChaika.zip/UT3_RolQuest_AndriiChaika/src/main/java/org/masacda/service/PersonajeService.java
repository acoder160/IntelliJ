package org.masacda.service;

public class PersonajeService {
}
