package org.masacda.service;

public class MisionService {
}
