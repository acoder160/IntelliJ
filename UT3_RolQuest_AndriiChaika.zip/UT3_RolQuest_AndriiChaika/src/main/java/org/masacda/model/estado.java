package org.masacda.model;

public enum estado {
}
