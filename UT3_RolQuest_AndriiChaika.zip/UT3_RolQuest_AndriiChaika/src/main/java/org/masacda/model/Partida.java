package org.masacda.model;

public class Partida {
}
