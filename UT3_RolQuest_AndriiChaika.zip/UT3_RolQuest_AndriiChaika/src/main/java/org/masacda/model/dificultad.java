package org.masacda.model;

public enum dificultad {
}
