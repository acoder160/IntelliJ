package org.masacda.model;

public enum clase {
    guerrero, mago, arquero
}
