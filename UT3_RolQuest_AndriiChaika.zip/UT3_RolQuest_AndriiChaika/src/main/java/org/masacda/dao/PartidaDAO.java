package org.masacda.dao;

public class PartidaDAO {
}
