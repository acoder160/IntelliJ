package org.masacda.dao;

public class MisionDAO {
}
