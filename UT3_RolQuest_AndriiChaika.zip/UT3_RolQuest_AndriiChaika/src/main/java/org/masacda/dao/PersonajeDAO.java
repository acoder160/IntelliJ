package org.masacda.dao;

public class PersonajeDAO imp{
}
